let add1 = (el) => {
    el.innerText++
}

let moreLikes = (el) => {
    el.innerText++
}

let accumulate = (el) => {
    el.innerText++
}

let plus1 = (el) => {
    el.innerText++
}